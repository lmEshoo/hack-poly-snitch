Arduino and C++ (for Windows)
http://www.arduino.cc/playground/Interfacing/CPPWindows

As I found it pretty hard finding the good information, or an already working code to handle Serial communication on windows based system, I finally made a class that do what is needed for basic Serial Communication, thanks to help of several forumers. Please note that this code might not be completely perfect so I encourage you to make any update needed so that it might become even better.

So now for the code which is consisting of two files, a header and a source code file. 

That's all you need, it has been tested with CodeBlocks and the MinGW compiler but should work fine with Visual Studio too. As for the way to use it I think the comments of the header makes it quite simple to understand though if needed you can contact me on the forum. 